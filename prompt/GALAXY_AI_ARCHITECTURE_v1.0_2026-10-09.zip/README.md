# Galaxy AI Architecture v1.0 — 09/10/2026

Bộ bàn giao định hướng kiến trúc và kế hoạch, không có product code hoặc credential.

- `GALAXY_AI_MASTER_PROMPT_v1.0_2026-10-09.md`: bản đầy đủ để Codex đọc và chuyển vào docs dự án; 18 mục chính, 16 quyết định, 36 điều kiện nghiệm thu, roadmap và nguồn.
- `GALAXY_AI_DECISION_MEMORY_v1.0_2026-10-09.md`: bản tóm tắt quyết định dài hạn.
- `START_HERE_CODEX_v1.0_2026-10-09.txt`: prompt khởi động khi đính kèm master.
- `MANIFEST.json`: hash để kiểm tra tính toàn vẹn các tệp trong gói.

Các đường dẫn repo và trạng thái trong tài liệu là đầu mối từ báo cáo trước. Chưa có truy cập repository máy chủ, chưa cài công cụ, chưa kết nối Workspace hay phát hành runtime trong lần tạo gói này.

Nguồn công khai đối chiếu ngày 09/10/2026; Codex phải xác minh lại hợp đồng/capability/giấy phép khi triển khai.
