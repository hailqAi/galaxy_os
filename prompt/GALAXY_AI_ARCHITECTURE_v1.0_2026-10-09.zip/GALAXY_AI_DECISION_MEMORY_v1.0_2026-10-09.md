# GALAXY AI — DECISION MEMORY v1.0

**Mốc:** 09/10/2026 — Asia/Ho_Chi_Minh  
**Trạng thái:** baseline kiến trúc tạm chốt; có thể bổ sung bằng revision.  
**Không phải:** xác nhận đã triển khai P1–P3, đã có Workspace entitlement, đã ghi vào repo hay runtime memory.

## Tóm tắt

Ngày 09/10/2026, chủ dự án tạm chốt GALAXY-AI-ARCH-20261009-v1.0, sẽ bổ sung theo revision. Giữ Galaxy OS v0.2 làm chuẩn nghiệp vụ và source of truth; SIWC dùng model mạnh nhất phù hợp được cấp quyền, không âm thầm downgrade/rewrite; giữ câu hỏi nguyên gốc, bổ sung ngữ cảnh đúng Project. Phiên liên tục do Galaxy quản lý, tách private/shared; không hứa phiên ChatGPT ẩn. Original files được lưu và kiểm hash, Markdown/structured data là dẫn xuất, memory là tri thức chắt lọc có nguồn. Upload Galaxy tối đa 10.000.000.000 byte mỗi file nhưng provider input theo khả năng thật; không nói đã đọc nguyên khi chỉ gửi phần. Tệp chat lưu bền vững dạng working, promote vào hồ sơ theo quyền. Kết quả trả lời/nguồn/ảnh/tệp được lưu đầy đủ, kiểm chứng, có link tải và Markdown; AI proposal không thành quyết định đã duyệt. Workspace là nhánh bổ trợ W0–W4, credential/cost/visibility/result-return và file transfer phải live-verify; không phá SIWC, remote OAuth vẫn hoãn. Công cụ GitHub qua adapter pin/version/license/sandbox/benchmark; ưu tiên OfficeCLI/AnyDoc/PPT Master, parser khó và memory engine đánh giá trước, không cài hàng loạt. Không đưa hồ sơ khách hàng vào Git, không bật provider-key paused, không tự mua credits/reset dữ liệu. Bản chuẩn và kế hoạch không chứng minh code hoàn thành; tái dùng approval P1 hợp lệ, bổ sung delta và nghiệm thu từng milestone.

## Quyết định đầy đủ

**D01 — Galaxy là hệ thống nghiệp vụ có thẩm quyền.** Một Project xuyên suốt; dữ liệu nhập một lần, có owner, lịch sử và phê duyệt. Không tạo CRM/Task/File/IAM/Approval/Memory nghiệp vụ thứ hai. Giữ định nghĩa 12 giai đoạn theo charter hiện hành, không tự phân loại lại.

**D02 — SIWC là đường suy luận thường trực.** Dùng model mạnh nhất phù hợp với yêu cầu và được account/route thực sự cấp quyền; không âm thầm hạ model, rút ngắn trả lời hoặc fallback sang provider-key đã paused. Không chọn model theo thứ tự tên. Cho người dùng xem model yêu cầu và model thực thi.

**D03 — Không giới hạn chủ đề hỏi đáp một cách tùy tiện.** AI được hỏi kiến thức, kỹ thuật, lập trình, kinh doanh, sáng tạo và các chủ đề hợp lệ. Project là ngữ cảnh, không là whitelist chủ đề. Giữ chính sách nhà cung cấp và quyền dữ liệu.

**D04 — Giữ nguyên câu hỏi.** Câu hỏi và tệp gắn với nó là bản gốc bất biến theo từng phiên bản message. Context được bổ sung riêng, không thay câu hỏi bằng một bản tóm tắt của model yếu. Edit message tạo revision mới.

**D05 — Mỗi Project có không gian AI liên tục do Galaxy quản lý.** Không hứa có cuộc chat GPT bí mật giữ mọi thứ phía OpenAI. Tách hội thoại riêng/chung, thread và actor, không dồn tất cả nhân viên vào một lịch sử chung.

**D06 — Original-first.** Giữ file gốc và hash; tạo Markdown/structured content làm bản dẫn xuất. Ưu tiên truyền bản gốc khi model/route/limit cho phép, báo rõ khi chỉ truyền trích đoạn hoặc bản render. Không hứa truyền nguyên mọi định dạng hoặc 10 GB cho GPT.

**D07 — File chat lưu tạm bền vững.** Tệp làm việc không nằm trong `/tmp` như kho cuối. Có hạn mức/retention, có thể chuyển sang hồ sơ khi người có quyền yêu cầu. Promote không đồng nghĩa phê duyệt tài liệu hay công bố cho khách hàng.

**D08 — Bảo toàn đầu ra.** Giữ đầy đủ nội dung trả lời có thể cung cấp cho người dùng, nguồn, ảnh/tệp, bản Markdown và quan hệ đầu vào–đầu ra. Không tự rút gọn câu trả lời tốt bằng một model khác. Không yêu cầu trích chain-of-thought ẩn.

**D09 — Kiểm chứng thay vì tin lời AI.** Code kiểm quyền, tính toán, định dạng, file tồn tại; model hỗ trợ rà soát có nguồn; người có thẩm quyền duyệt nghiệp vụ. “AI làm xong bản nháp” khác “công việc hoàn thành” và “tài liệu đã phát hành”.

**D10 — Memory là tri thức có nguồn, không phải toàn bộ lời AI thành sự thật.** Lưu lịch sử đầy đủ riêng; trích memory cốt lõi có trạng thái, nguồn, version và hiệu lực. Tách user-confirmed/source-grounded/AI-proposed/superseded.

**D11 — Cách ly Project là ranh giới dữ liệu.** Áp dụng tại DB, source query, cache, retrieval, embeddings, worker, summaries, tool result và provider session; kể cả admin có quyền nhiều Project cũng không tự trộn nguồn.

**D12 — Workspace Agents là nhánh bổ trợ có điều kiện.** Credential, workspace entitlement, chi phí, tool access, output destination, privacy và live acceptance riêng. Không phá SIWC và không làm điều kiện chặn toàn bộ nền tảng.

**D13 — Không hứa “phiên ẩn” cho Workspace.** SIWC không tạo cuộc chat UI theo thiết kế đang chọn. Workspace có liên hệ tới hội thoại ChatGPT; visibility/retention cần xác minh và người dùng chấp thuận trước khi đưa dữ liệu thật.

**D14 — Công cụ bổ sung qua adapter có hợp đồng.** Tham khảo tư tưởng model/harness/tools/skills/session/storage tách rời của DeepSeek Harness; không đổi sang model DeepSeek hay thay toàn backend. Công cụ chỉ AVAILABLE khi executor sẵn sàng và quyền/capability phù hợp.

**D15 — Giữ các giới hạn hiện hành.** Không sửa OAuth/callback/refresh SIWC hay remote OAuth trong đợt này; không bật lại bốn API-key provider; không tự mua credits/gói/GPU/VPS; không reset DB/volume/Git; không công khai cổng nội bộ. Domain hiện có tiếp tục phục vụ bằng kiến trúc hiện hữu.

**D16 — Baseline tạm chốt, có thể bổ sung.** Thay đổi sau cần có diff quyết định và đánh giá ảnh hưởng, không buộc bắt đầu lại toàn bộ kiến trúc.

## Nguồn chuẩn đi cùng

Đọc `GALAXY_AI_MASTER_PROMPT_v1.0_2026-10-09.md` để lấy các hợp đồng, roadmap, kế hoạch Workspace, tool adoption, A01–A36 và nguồn xác minh. Khi Codex đưa vào repo, link tới đường dẫn thật đã ghi; không tạo thêm bản chuẩn cạnh tranh.

## Phân biệt nơi lưu

Bộ nhớ phát triển này nằm trong docs Git. Lịch sử, file và memory của Project khách hàng phải nằm trong DB/storage có ACL, không đưa vào Git.

## Bổ sung sau

Mỗi thay đổi có mã quyết định, nguồn chỉ đạo, ngày, phạm vi thay thế, ảnh hưởng source/tests/runtime và trạng thái phê duyệt. Không mở lại các quyết định cũ không thay đổi.
